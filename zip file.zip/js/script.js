﻿const preloader = document.getElementById('preloader');
window.addEventListener('load', () => {
    if (preloader) {
        preloader.classList.add('preloader--hidden');
        setTimeout(() => preloader.remove(), 700);
    }
});

window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (!header) return;
    if (window.scrollY > 40) {
        header.style.background = 'rgba(7, 11, 20, .95)';
        header.style.boxShadow = '0 18px 45px rgba(0, 0, 0, .18)';
    } else {
        header.style.background = 'rgba(7, 11, 20, .75)';
        header.style.boxShadow = 'none';
    }
});
